# Portal do Cliente — React + Firebase (Plano Gratuito Spark & LGPD)

Aplicação web responsiva em **React + TypeScript + Tailwind CSS** integrada ao **Firebase (Authentication + Firestore)** em conformidade com a **LGPD (Lei 13.709/2018)** e pronta para hospedagem gratuita no **GitHub Pages** — **100% no plano gratuito (Spark), sem precisar cadastrar cartão no Google Cloud**.

## Funcionalidades
- **Banco Privado**: isolamento rigoroso por empresa (`empresaId`) e por cliente (`clienteId`) via `firestore.rules`.
- **Coleta Mínima (Sem CPF)**: coleta apenas Nome completo, WhatsApp e E-mail.
- **Painel da Empresa**: Dashboard financeiro com gráfico de recebimentos, cadastro de clientes (com senha temporária gerada automaticamente), boletos com PIX Copia e Cola e lembrete via WhatsApp, envio/visualização/download de PDFs reais (armazenados em blocos privados no Firestore até 5 MB), chamados e relatório com exportação CSV.
- **Portal do Cliente**: visualização e pagamento PIX de boletos, download de boleto PDF, visualização/download de documentos PDF, abertura de chamados, edição de perfil e **exclusão total LGPD** (Firestore + Auth).

---

## Como conectar seu próprio projeto Firebase (100% Grátis — Sem Cartão)
1. Crie um projeto no [Console do Firebase](https://console.firebase.google.com/).
2. Ative **Authentication** → *Sign-in method* → **E-mail/senha** (e opcionalmente **Google**).
3. Ative **Firestore Database** → criar no banco padrão **`(default)`** em **Modo de produção** e cole o conteúdo de `firestore.rules` na aba **Regras** (depois clique em **Publicar**).
   > **Não precisa ativar o Firebase Storage** nem atualizar para o plano Blaze/pago: os arquivos PDF já são gravados com segurança diretamente no Firestore privado.
4. Em **Configurações do Projeto → Seus aplicativos → Web**, copie suas credenciais e configure de uma das duas formas:
   - **Opção A (Direto no código)**: cole os valores em `firebaseConfig` no topo de `src/firebase.ts` (deixe `firestoreDatabaseId: ''`).
   - **Opção B (Variáveis de Ambiente / GitHub Secrets)**: crie um `.env` local (baseado em `.env.example`) ou cadastre os Secrets `VITE_FIREBASE_*` no repositório do GitHub.
5. Em **Authentication → Settings → Authorized domains**, adicione o domínio do GitHub Pages (ex.: `seu-usuario.github.io`) caso use login com Google.

---

## Como hospedar no GitHub Pages
1. Suba os arquivos deste projeto diretamente na **raiz** do seu repositório no GitHub (`index.html`, `package.json`, `src/`, `.github/` devem ficar na raiz, não dentro de outra subpasta), na branch `main` ou `master`.
2. No repositório, acesse **Settings → Pages → Build and deployment → Source** e selecione **GitHub Actions** (não deixe em *Deploy from a branch*).
3. (Opcional, se optar pela Opção B) Cadastre as variáveis `VITE_FIREBASE_*` em **Settings → Secrets and variables → Actions**.
4. A cada `push` na branch `main` ou `master`, o workflow `.github/workflows/deploy.yml` executa `npm install && npm run build` e publica automaticamente a pasta `dist/`.

## Desenvolvimento local
```bash
npm install
npm run dev
```
