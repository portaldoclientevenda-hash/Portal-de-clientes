# Security Specification — Portal do Cliente (LGPD)

## 1. Data Invariants
1. **Strict Tenant Isolation (Empresa)**: An Empresa (`request.auth.uid`) may only read, create, update, or delete records (`clientes`, `boletos`, `documentos`, `chamados`, `atividades`) where `empresaId == request.auth.uid` and `exists(/databases/$(database)/documents/empresas/$(request.auth.uid))`.
2. **Strict Client Isolation (Cliente)**: A Cliente (`request.auth.uid`) may only read records where `clienteId == request.auth.uid`, may only update their own allowed profile fields (`nome`, `whatsapp`, `email`, `updatedAt`) without changing `empresaId`, `clienteId`, or `papel`, may only create `chamados` linked to their own `clienteId` and verified `empresaId`, and may delete their own records for LGPD Art. 18 erasure.
3. **No Sensitive Data (Sem CPF)**: No document in any collection may contain `cpf`, `rg`, `endereco`, `dataNascimento`, or arbitrary ghost fields (enforced via strict `keys().hasOnly(...)`).
4. **Immutable Ownership & Audit Timestamps**: `empresaId`, `clienteId`, `createdAt`, and `lgpdConsentAt` cannot be modified after creation. All `createdAt` and `updatedAt` timestamps must equal `request.time`.
5. **Terminal State Locking**: Once a Boleto reaches `status == 'Pago'`, or a Chamado reaches `status == 'Resolvido'`, no further mutations are permitted.
6. **Storage Isolation**: PDFs under `/documentos/{empresaId}/{clienteId}/{nomeArquivo}` are readable only by `empresaId` or `clienteId`, writable only by `empresaId` (PDF only, <= 15MB), and deletable by `empresaId` or `clienteId` (for LGPD erasure).

## 2. Dirty Dozen Adversarial Payloads (Must Return PERMISSION_DENIED)
1. **Unauthenticated Read/Write**: Any operation when `request.auth == null`.
2. **Self-Assigned Role Escalation (Empresa)**: Creating `/empresas/{uid}` with `papel: "admin"` instead of `"empresa"`, or `empresaId != request.auth.uid`.
3. **Ghost Field / PII Injection (CPF)**: Creating `/clientes/{id}` with an extra field `{ "cpf": "12345678900" }` or `{ "isAdmin": true }` (blocked by `hasOnly`).
4. **Cross-Tenant Empresa Snooping**: Empresa A reading or listing `/boletos` where `empresaId == EmpresaB`.
5. **Cross-Client Snooping**: Cliente A reading or listing `/documentos` or `/boletos` where `clienteId == ClienteB`.
6. **Client Self-Registration Attack**: A user calling `create` on `/clientes/{uid}` when they are NOT a registered Empresa (`empresas/{request.auth.uid}` does not exist).
7. **Client Creating Fake Boleto**: A Cliente attempting to `create` or `update` a document in `/boletos/{id}`.
8. **Client Privilege Mutation**: A Cliente attempting to update `/clientes/{uid}` to change `empresaId`, `papel`, or `lgpdConsent`.
9. **Terminal State Tampering (Boleto)**: Empresa attempting to update a Boleto whose existing `status == 'Pago'` back to `'Pendente'`.
10. **Terminal State Tampering (Chamado)**: Empresa attempting to update a Chamado whose existing `status == 'Resolvido'`.
11. **Timestamp Forgery**: Creating a record with a backdated `createdAt` (`new Date('2020-01-01')`) instead of `request.time`.
12. **Resource Poisoning / Oversized ID or String**: Writing a 200KB `titulo` or an invalid document ID containing `/` or spaces (`../admin`).
