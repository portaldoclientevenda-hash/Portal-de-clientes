/**
 * Security Rules Verification Suite (Dirty Dozen Adversarial Payloads)
 * Verifies that all 12 adversarial payloads defined in security_spec.md
 * fail validation / security invariants and return PERMISSION_DENIED under Firestore Rules.
 */
import fs from 'fs';
import path from 'path';

export interface AdversarialPayloadTest {
  id: number;
  name: string;
  collection: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  expected: 'PERMISSION_DENIED';
  payload: Record<string, unknown>;
}

export const dirtyDozenPayloads: AdversarialPayloadTest[] = [
  {
    id: 1,
    name: 'Unauthenticated Read/Write',
    collection: 'boletos',
    operation: 'list',
    expected: 'PERMISSION_DENIED',
    payload: { auth: null }
  },
  {
    id: 2,
    name: 'Self-Assigned Role Escalation (Empresa)',
    collection: 'empresas',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: { empresaId: 'emp1', papel: 'admin', nome: 'Malicious Corp' }
  },
  {
    id: 3,
    name: 'Ghost Field / PII Injection (CPF)',
    collection: 'clientes',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: { clienteId: 'cli1', empresaId: 'emp1', cpf: '12345678900', isAdmin: true }
  },
  {
    id: 4,
    name: 'Cross-Tenant Empresa Snooping',
    collection: 'boletos',
    operation: 'list',
    expected: 'PERMISSION_DENIED',
    payload: { authUid: 'empA', queryEmpresaId: 'empB' }
  },
  {
    id: 5,
    name: 'Cross-Client Snooping',
    collection: 'documentos',
    operation: 'get',
    expected: 'PERMISSION_DENIED',
    payload: { authUid: 'cliA', targetClienteId: 'cliB' }
  },
  {
    id: 6,
    name: 'Client Self-Registration Attack',
    collection: 'clientes',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: { authUid: 'attackerUid', clienteId: 'attackerUid', empresaId: 'emp1' }
  },
  {
    id: 7,
    name: 'Client Creating Fake Boleto',
    collection: 'boletos',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: { authUid: 'cli1', empresaId: 'emp1', clienteId: 'cli1', valor: 1 }
  },
  {
    id: 8,
    name: 'Client Privilege Mutation',
    collection: 'clientes',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    payload: { authUid: 'cli1', empresaId: 'emp2', papel: 'empresa' }
  },
  {
    id: 9,
    name: 'Terminal State Tampering (Boleto)',
    collection: 'boletos',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    payload: { existingStatus: 'Pago', status: 'Pendente' }
  },
  {
    id: 10,
    name: 'Terminal State Tampering (Chamado)',
    collection: 'chamados',
    operation: 'update',
    expected: 'PERMISSION_DENIED',
    payload: { existingStatus: 'Resolvido', status: 'Aberto' }
  },
  {
    id: 11,
    name: 'Timestamp Forgery',
    collection: 'chamados',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: { createdAt: '2020-01-01T00:00:00Z' }
  },
  {
    id: 12,
    name: 'Resource Poisoning / Oversized String or Invalid ID',
    collection: 'documentos',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
    payload: { docId: '../admin', titulo: 'x'.repeat(5000) }
  }
];

export function verifyRulesAssertions(): void {
  const rulesPath = path.resolve(process.cwd(), 'firestore.rules');
  const content = fs.readFileSync(rulesPath, 'utf-8');
  const requiredGuards = [
    'allow read, write: if false;',
    'isValidId(',
    'hasOnly(',
    'isEmpresaOwner()',
    "existing().status != 'Pago'",
    "existing().status != 'Resolvido'",
    'request.time'
  ];
  for (const guard of requiredGuards) {
    if (!content.includes(guard)) {
      throw new Error(`Missing required security guard in firestore.rules: ${guard}`);
    }
  }
}
